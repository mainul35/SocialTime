
import com.socialtime.dao.DaoUsers;
import com.socialtime.model.Users;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class Main {
    public static void main(String[] args) {
        DaoUsers userDao = new DaoUsers();
        userDao.read();
    }
}
