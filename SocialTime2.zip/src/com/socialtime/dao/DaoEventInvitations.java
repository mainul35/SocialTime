/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.socialtime.dao;

import com.socialtime.model.Eventinvitations;
import com.socialtime.model.Useravailability;
import com.socialtime.util.SocialTimeSessionFactory;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author Mainul35
 */
public class DaoEventInvitations {
    public static List<Eventinvitations> listEventInvitations(int isAccepted) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        String hql = "FROM Eventinvitations ei "
                + "WHERE ei.accepted =:isAccepted ";
        Query query = session.createQuery(hql);
        query.setParameter("isAccepted", isAccepted);
        List<Eventinvitations> eventinvitationsList = (List<Eventinvitations>) query.list();
        session.close();
        return eventinvitationsList;
    }
    
    public static List<Eventinvitations> listEventInvitations(String email) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        String hql = "FROM Eventinvitations ei "
                + "WHERE ei.users.email =:email ";
        Query query = session.createQuery(hql);
        query.setParameter("email", email);
        List<Eventinvitations> eventinvitationsList = (List<Eventinvitations>) query.list();
        session.close();
        return eventinvitationsList;
    }
    
    public static boolean addEventInvitation(Eventinvitations evtInvitation) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        session.beginTransaction();
        try {
            session.save(evtInvitation);
            session.getTransaction().commit();
            System.out.println("Saved");
        } catch (Exception e) {
            e.printStackTrace();
            session.getTransaction().rollback();
            session.close();
            return false;
        }
        session.close();
        return true;
    }

    public static void update(Eventinvitations ei) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        session.beginTransaction();
        Eventinvitations eventinvitations = (Eventinvitations) session.load(Eventinvitations.class, ei.getInvitationId());
        eventinvitations.setEvent(ei.getEvent());
        eventinvitations.setAccepted(ei.getAccepted());
        eventinvitations.setUsers(ei.getUsers());
        session.getTransaction().commit();
        session.close();
    }
    
    public static void delete(Integer id) {
        Eventinvitations ei = findByEmail(id);
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        session.beginTransaction();
        session.delete(ei);
        session.getTransaction().commit();
        session.close();
    }

    public static Eventinvitations findByEmail(Integer id) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        Eventinvitations e = (Eventinvitations) session.load(Eventinvitations.class, id);
        session.close();
        return e;
    }
}
