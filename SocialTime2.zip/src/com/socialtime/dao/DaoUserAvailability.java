/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.socialtime.dao;

import com.socialtime.model.Useravailability;
import com.socialtime.util.SocialTimeSessionFactory;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Mainul35
 */
public class DaoUserAvailability {

    public static List<Useravailability> listUserAvailability(String email) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        String hql = "FROM Useravailability ua "
                + "WHERE ua.users.email =:em";
        Query query = session.createQuery(hql);
        query.setParameter("em", email);
        List<Useravailability> useravailabilityList = (List<Useravailability>) query.list();
        session.close();
        return useravailabilityList;
    }

    public static List<Useravailability> listUserAvailability(String email, int dayId) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        String hql = "FROM Useravailability ua "
                + "WHERE ua.users.email =:em "
                + "AND ua.day.dayId =:id ";
        Query query = session.createQuery(hql);
        query.setParameter("em", email);
        query.setParameter("id", dayId);
        List<Useravailability> useravailabilityList = (List<Useravailability>) query.list();
        session.close();
        return useravailabilityList;
    }

    public static boolean addAvailability(Useravailability u) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        session.beginTransaction();
        try {
            session.save(u);
            session.getTransaction().commit();
            System.out.println("Saved");
        } catch (Exception e) {
            e.printStackTrace();
            session.getTransaction().rollback();
            session.close();
            return false;
        }
        session.close();
        return true;
    }

    public static boolean deleteTimeSlots(String email, int dayId) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        try {
            // your code
            String hql = "delete from Useravailability ua where ua.users.email= :email AND ua.day.dayId= :dayId ";
            Query query = session.createQuery(hql);
            query.setString("email", email);
            query.setInteger("dayId", dayId);
            query.executeUpdate();
            // your code end
            transaction.commit();
            return true;
        } catch (Throwable t) {
            transaction.rollback();
            return false;
        }
    }
}
