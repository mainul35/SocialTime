/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.socialtime.dao;

import com.socialtime.model.Event;
import com.socialtime.model.Users;
import com.socialtime.util.SocialTimeSessionFactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.mapping.Map;

/**
 *
 * @author Mainul35
 */
public class DaoEvent {

    public static List<Event> read() {
        List<Event> events = null;
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        Query query = session.createQuery("FROM Event ");
        events = (List<Event>) query.list();
        session.close();
        return events;
    }

    public static List<Event> myEvents(String email) {
        List<Event> events = null;
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        Query query = session.createQuery("FROM Event e where e.users.email =:email ");
        query.setString("email", email);
        events = (List<Event>) query.list();
        session.close();
        return events;
    }

    public static HashMap<String, String> getEventByEventId(int eventId) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        String sql = "SELECT  evt.eventName as event_name,\n"
                + "                evt.eventLocation as event_location, \n"
                + "                (SELECT h.`hour` \n"
                + "									FROM hours h, `event` evt \n"
                + "									WHERE h.hourId = evt.startTime \n"
                + "									AND evt.eventId = '"+eventId+"') as start_hour,\n"
                + "                (SELECT h.`hour` \n"
                + "									FROM hours h, `event` evt \n"
                + "									WHERE h.hourId = evt.endTime \n"
                + "									AND evt.eventId = '"+eventId+"') as end_hour,\n"
                + "                (SELECT d.dayName \n"
                + "									FROM `day` d, `event` evt \n"
                + "									WHERE d.dayId = evt.`day`\n"
                + "									AND evt.eventId = '"+eventId+"') as day_name,\n"
                + "                (SELECT u.`name` \n"
                + "									FROM users u, `event` evt \n"
                + "									WHERE u.email = evt.hostEmail\n"
                + "									AND evt.eventId = '"+eventId+"') as host_name\n"
                + "                FROM `event` evt\n"
                + "                WHERE evt.eventId = '"+eventId+"'";
        Query query = session.createSQLQuery(sql);
        query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
        List list = query.list();
        HashMap row = null;
        for (Object object : list) {
            row = (HashMap<String, String>) object;
        }
        session.close();
        return row;
    }

    public static void updateEventVote(String timeSlot, int eventId) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        session.beginTransaction();
        StringTokenizer tokenizer = new StringTokenizer(timeSlot, "-");
        String startTime = tokenizer.nextToken();
        String endTime = tokenizer.nextToken();
        String sql = "UPDATE `event` e\n"
                + "SET e.startTime = '" + startTime + "', e.endTime = '" + endTime + "'\n"
                + "WHERE e.eventId = '" + eventId + "';";
        Query query = session.createSQLQuery(sql);
        query.executeUpdate();
        session.getTransaction().commit();
        session.close();
    }

    public static boolean addEvent(Event event) {

        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        session.beginTransaction();
        try {
            session.save(event);
            session.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            session.getTransaction().rollback();
            session.close();
            return false;
        }
        session.close();
        return true;
    }

    public static void update(Event e) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        session.beginTransaction();
        Event event = (Event) session.load(Event.class, e.getUsers().getEmail());
        event.setDay(e.getDay());
        event.setEventLocation(e.getEventLocation());
        event.setEventName(e.getEventName());
        event.setEventinvitationses(e.getEventinvitationses());
        event.setHoursByEndTime(e.getHoursByEndTime());
        event.setHoursByStartTime(e.getHoursByStartTime());
        event.setMinAttendees(e.getMinAttendees());
        event.setMinTresholders(e.getMinTresholders());
        event.setUsers(e.getUsers());
        session.getTransaction().commit();
        session.close();
    }

}
