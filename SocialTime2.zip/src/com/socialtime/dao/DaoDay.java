/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.socialtime.dao;

import com.socialtime.model.Day;
import com.socialtime.util.SocialTimeSessionFactory;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author HP
 */
public class DaoDay {
    public static List<Day> getDays(){
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        String hql = "FROM Day ";
        Query query = session.createQuery(hql);
        List<Day> days= (List<Day>)query.list();
        return days;
    }
}
