/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.socialtime.dao;

import com.socialtime.model.Eventinvitations;
import com.socialtime.model.Eventvotes;
import com.socialtime.model.Useravailability;
import com.socialtime.util.SocialTimeSessionFactory;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author Mainul35
 */
public class DaoEventVotes {

    public static List<Eventvotes> listEventVotes() {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        String hql = "FROM Eventvotes ev ";
        Query query = session.createQuery(hql);
//        query.setParameter("eventId", eventId);
        List<Eventvotes> eventvotesList = (List<Eventvotes>) query.list();
        session.close();
        return eventvotesList;
    }

    public static ArrayList<HashMap<String, Object>> listEventVotes(int eventId) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        String sql = "SELECT ev.countVotes, ev.startTimeId, ev.endTimeId\n"
                + "FROM `event` e, eventvotes ev\n"
                + "WHERE ev.eventId = e.eventId\n"
                + "AND ev.countVotes = 1\n"
                + "AND ev.eventId = '" + eventId + "';";
        Query query = session.createSQLQuery(sql);
        query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
        List list = query.list();
        HashMap<String, Object> row = null;
        ArrayList<HashMap<String, Object>> al = new ArrayList<>();
        for (Object object : list) {
            al.add((HashMap<String, Object>) object);
        }
        session.close();

//        for (int p = 0; p < al.size(); p++) {
//            String timeSlot = al.get(p).get("startTimeId") + "-" + al.get(p).get("endTimeId");
//            System.out.println(timeSlot);
//        }
        return al;
    }

    public static void updateEventVote(Eventvotes eventvotes) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        session.beginTransaction();
        Query query = session.createSQLQuery("update eventvotes ev set ev.countVotes = :cv where ev.poolId=:pId");
        query.setParameter("cv", 1);
        query.setParameter("pId", eventvotes.getPoolId());
        query.executeUpdate();
        session.getTransaction().commit();
        session.close();

        session = SocialTimeSessionFactory.getSessionFactory().openSession();
        session.beginTransaction();
        query = session.createSQLQuery("delete from eventvotes where invitationId = '" + eventvotes.getEventinvitations().getInvitationId() + "' and countVotes = '0'");
        query.executeUpdate();
        session.getTransaction().commit();
        session.close();

        System.out.println("Updated");
    }

    public static boolean isVoted(int invitationId) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        Query query = session.createSQLQuery("SELECT ev.countVotes\n"
                + "FROM eventvotes ev, eventinvitations ei\n"
                + "WHERE ev.invitationId = ei.invitationId\n"
                + "AND ei.invitationId = '" + invitationId + "';");
        query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
        List list = query.list();
        HashMap row = null;
        for (Object object : list) {
            row = (HashMap<String, String>) object;
            break;
        }
        System.err.println("Status = " + row.get("countVotes"));
        int status = Integer.parseInt(row.get("countVotes").toString());
        session.close();

        if (status == 1) {
            return true;
        } else {
            return false;
        }
    }

    public static int getEventIdByInvitationId(int invitationId) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        session.beginTransaction();
        String sql = "SELECT ev.eventId\n"
                + "FROM eventvotes ev\n"
                + "WHERE ev.invitationId = '" + invitationId + "'";
        Query query = session.createSQLQuery(sql);
        query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
        List list = query.list();
        HashMap<String, Object> row = null;
//        ArrayList<HashMap<String, Object>> al = new ArrayList<>();
        for (Object object : list) {
            row = (HashMap<String, Object>) object;
        }
        return Integer.parseInt(row.get("eventId").toString());
    }

    public static boolean addEventvote(Eventvotes ev) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        session.beginTransaction();
        try {
            session.save(ev);
            session.getTransaction().commit();
            System.out.println("Saved");
        } catch (Exception e) {
            e.printStackTrace();
            session.getTransaction().rollback();
            session.close();
            return false;
        }
        session.close();
        return true;
    }

    public static List<Eventvotes> listEventVotesByInvitationId(int invitationId) {
        Session session = SocialTimeSessionFactory.getSessionFactory().openSession();
        String hql = "FROM Eventvotes ev WHERE ev.eventinvitations.invitationId =:invId ";
        Query query = session.createQuery(hql);
        query.setParameter("invId", invitationId);
        List<Eventvotes> eventvotesList = (List<Eventvotes>) query.list();
        session.close();
        return eventvotesList;
    }
}
