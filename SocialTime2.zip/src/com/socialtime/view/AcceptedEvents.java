/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.socialtime.view;

import com.socialtime.dao.DaoEvent;
import com.socialtime.dao.DaoEventInvitations;
import com.socialtime.dao.DaoEventVotes;
import com.socialtime.dao.DaoUserAvailability;
import com.socialtime.model.Eventinvitations;
import com.socialtime.model.Eventvotes;
import com.socialtime.model.Useravailability;
import com.socialtime.util.windowComponent.AdvancedButton;
import com.socialtime.util.windowComponent.AdvancedLabel;
import com.socialtime.util.windowComponent.AdvancedPanel;
import com.socialtime.util.windowComponent.AdvancedRadioButton;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author Mainul35
 */
public class AcceptedEvents {

    JPanel pnlAcceptedEvents;
    static int i = 0;
    static AdvancedPanel[] aContainer = new AdvancedPanel[100];
    //JPanel();
    static AdvancedPanel[] aComponentHolder = new AdvancedPanel[100];
//    JCheckBox("Edit Permission");
    static AdvancedButton[] aBtnFeasibleTimeSlots = new AdvancedButton[100];
    //JButton("Submit");
    static AdvancedButton[] aBtnViewEventDetails = new AdvancedButton[100];

    static AdvancedButton[] aBtnCancelGoing = new AdvancedButton[100];
    //JButton("Close");
    static AdvancedLabel[] aLblText = new AdvancedLabel[100];

    public JPanel getAcceptedEvents(String email) {

        pnlAcceptedEvents = new JPanel(new GridLayout(5, 0, 10, 8));
        final List<Eventinvitations> es = DaoEventInvitations.listEventInvitations(email);
//        AcceptedEvents events = new AcceptedEvents();
        for (i = 0; i < es.size(); i++) {
            if (es.get(i).getAccepted() == 1 && !es.get(i).getEvent().getUsers().getEmail().equals(email)) {
                final int invitationId = es.get(i).getInvitationId();
                aLblText[i] = new AdvancedLabel("<html>" + es.get(i).getEvent().getUsers().getName() + " Invited you for " + es.get(i).getEvent().getEventName()
                        + " event.<br>"
                        + "Day: " + es.get(i).getEvent().getDay().getDayName() + "<br>"
                        + "</html>");

                aComponentHolder[i] = new AdvancedPanel();
                aContainer[i] = new AdvancedPanel();
                aBtnFeasibleTimeSlots[i] = new AdvancedButton("Vote Feasible timeslot");
                aBtnViewEventDetails[i] = new AdvancedButton("View Event Details");
                aBtnCancelGoing[i] = new AdvancedButton("Cancel event");

                aBtnFeasibleTimeSlots[i].setId(invitationId);
                aBtnViewEventDetails[i].setId(invitationId);
                aBtnCancelGoing[i].setId(invitationId);
                aLblText[i].setId(invitationId);
                aContainer[i].setId(invitationId);
                aComponentHolder[i].setId(invitationId);
                System.err.println("@Line 77 " + i);
                aBtnFeasibleTimeSlots[i].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        System.out.println(((AdvancedButton) ae.getSource()).getId());
                        if (DaoEventVotes.isVoted(((AdvancedButton) ae.getSource()).getId()) == true) {
                            JOptionPane.showMessageDialog(Home.home, "You have already voted timeslot.");
                        } else {
                            final JFrame frame = new JFrame("All feasible timeslots");
                            frame.setLayout(new BorderLayout());
//                        JScrollPane scrollPane = new JScrollPane();
                            JPanel pnlTimeSlots = new JPanel(new GridLayout(14, 0, 10, 5));
//                        scrollPane.add(pnlTimeSlots);
                            frame.add(pnlTimeSlots, BorderLayout.CENTER);
                            JButton btnVote = new JButton("Vote");
                            frame.add(btnVote, BorderLayout.SOUTH);
                            final List<Eventvotes> listEvtVotes = DaoEventVotes.listEventVotesByInvitationId(invitationId);
                            for (Eventvotes listEvtVote : listEvtVotes) {
                                System.out.println(listEvtVote.getHoursByStartTimeId().getHour()+"-"+listEvtVote.getHoursByEndTimeId().getHour());
                            }
                            final AdvancedRadioButton[] rdoVote = new AdvancedRadioButton[listEvtVotes.size()];

                        System.out.println("@Line 99 "+listEvtVotes.size());
                            for (int p = 0; p < es.size(); p++) {
                                System.out.println(p);

                                if (((AdvancedButton) ae.getSource()).equals(aBtnFeasibleTimeSlots[p])) {

                                    if (es.get(p).getAccepted() == 1) {
                                        for (int j = 0; j < listEvtVotes.size(); j++) {
                                            if (listEvtVotes.get(j).getEventinvitations().getInvitationId() == es.get(p).getInvitationId()) {
                                                rdoVote[j] = new AdvancedRadioButton(listEvtVotes.get(j).getHoursByStartTimeId().getHour() + " - " + listEvtVotes.get(j).getHoursByEndTimeId().getHour());
                                                rdoVote[j].setId(invitationId);
                                                pnlTimeSlots.add(rdoVote[j]);
                                                rdoVote[j].addActionListener(new ActionListener() {
                                                    @Override
                                                    public void actionPerformed(ActionEvent ae) {
                                                        AdvancedRadioButton radioButton = (AdvancedRadioButton) ae.getSource();
                                                        for (int p = 0; p < rdoVote.length; p++) {
                                                            System.out.println(p);
                                                            if (rdoVote[p].isSelected()) {
                                                                rdoVote[p].setSelected(false);
                                                            }
                                                        }
                                                        radioButton.setSelected(true);
                                                    }
                                                });
                                            }
                                        }
                                    }
                                }
                            }
                            btnVote.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent ae) {
                                    for (int p = 0; p < listEvtVotes.size(); p++) {
                                        if (rdoVote[p].isSelected()) {
                                            DaoEventVotes.updateEventVote(listEvtVotes.get(p));
                                            JOptionPane.showMessageDialog(frame, "Vote confirmed.");
                                            frame.dispose();
                                        }
                                    }
                                }
                            });
                            frame.setVisible(true);
                            frame.setSize(450, 350);
                            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                        }
                    }
                });
                aBtnCancelGoing[i].addActionListener(
                        new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae
                    ) {
                        System.out.println(i);
                        for (int p = 0; p < es.size(); p++) {
                            System.out.println(p);
                            if ((ae.getSource()) == aBtnCancelGoing[p]) {
                                es.get(p).setAccepted(2);
                                DaoEventInvitations.update(es.get(p));
                                pnlAcceptedEvents.remove(aContainer[p]);
                                pnlAcceptedEvents.revalidate();
                                pnlAcceptedEvents.repaint();
                            }
                        }
                    }
                }
                );

                aBtnViewEventDetails[i].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        AdvancedButton button = (AdvancedButton)ae.getSource();
                        int id = button.getId();
                        HashMap<String, String> hm = DaoEvent.getEventByEventId(DaoEventVotes.getEventIdByInvitationId(invitationId));
                        WindowEventDetails windowEventDetails = new WindowEventDetails(
                                hm.get("event_name"),
                                hm.get("day_name"),
                                hm.get("host_name"),
                                ((hm.get("start_hour")+" - "+hm.get("end_hour")).equals("00:00 - 00:00")?"Not confirmed yet":hm.get("start_hour")+" - "+hm.get("end_hour")),
                                hm.get("event_location")
                        );
                        windowEventDetails.setTitle("Event details");
                        windowEventDetails.setVisible(true);
                        windowEventDetails.setDefaultCloseOperation(2);
                    }
                });
                aComponentHolder[i].setLayout(
                        new GridLayout(1, 3));
                aComponentHolder[i].add(aBtnFeasibleTimeSlots[i], 0);
                aComponentHolder[i].add(aBtnViewEventDetails[i], 1);
                aComponentHolder[i].add(aBtnCancelGoing[i], 2);

                aContainer[i].setLayout(
                        new GridLayout(2, 1));
                aContainer[i].add(aLblText[i], 0);
                aContainer[i].add(aComponentHolder[i], 1);
                aComponentHolder[i].setBackground(Color.decode("#AA99DD"));
                aContainer[i].setBackground(Color.decode("#AA99DD"));
                aComponentHolder[i].revalidate();
                aComponentHolder[i].repaint();
                aContainer[i].revalidate();
                aContainer[i].repaint();

                pnlAcceptedEvents.add(aContainer[i], 0);
                pnlAcceptedEvents.revalidate();

                pnlAcceptedEvents.repaint();
            }
        }

        return pnlAcceptedEvents;
    }
}