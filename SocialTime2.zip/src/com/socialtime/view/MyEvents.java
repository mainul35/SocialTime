/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.socialtime.view;

import com.socialtime.dao.DaoEvent;
import com.socialtime.dao.DaoEventInvitations;
import com.socialtime.dao.DaoEventVotes;
import com.socialtime.dao.DaoUserAvailability;
import com.socialtime.model.Event;
import com.socialtime.model.Eventinvitations;
import com.socialtime.model.Eventvotes;
import com.socialtime.model.Useravailability;
import com.socialtime.util.windowComponent.AdvancedButton;
import com.socialtime.util.windowComponent.AdvancedLabel;
import com.socialtime.util.windowComponent.AdvancedPanel;
import com.socialtime.util.windowComponent.AdvancedRadioButton;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author Mainul35
 */
public class MyEvents {

    JPanel pnlAcceptedEvents;
    static int i = 0;
    static AdvancedPanel[] aContainer = new AdvancedPanel[100];
    //JPanel();
    static AdvancedPanel[] aComponentHolder = new AdvancedPanel[100];
//    JCheckBox("Edit Permission");
    static AdvancedButton[] aBtnVotedTimeSlots = new AdvancedButton[100];
    //JButton("Submit");
    static AdvancedButton[] aBtnViewEventDetails = new AdvancedButton[100];

    static AdvancedButton[] aBtnCancelGoing = new AdvancedButton[100];
    //JButton("Close");
    static AdvancedLabel[] aLblText = new AdvancedLabel[100];

    public JPanel getMyEvents(String email) {

        pnlAcceptedEvents = new JPanel(new GridLayout(5, 0, 10, 8));
        final List<Event> evts = DaoEvent.myEvents(email);
        if (!evts.isEmpty()) {
//        AcceptedEvents events = new AcceptedEvents();
            for (i = 0; i < evts.size(); i++) {
//            if (es.get(i).getAccepted() == 1 && !es.get(i).getEvent().getUsers().getEmail().equals(email)) {
                final int eventId = evts.get(i).getEventId();
                aLblText[i] = new AdvancedLabel(
                        "<html>You created " + evts.get(i).getEventName() + " event.<br>"
                        + "</html>");

                aComponentHolder[i] = new AdvancedPanel();
                aContainer[i] = new AdvancedPanel();
                aBtnVotedTimeSlots[i] = new AdvancedButton("See votes");
                aBtnViewEventDetails[i] = new AdvancedButton("View Event Details");
                aBtnCancelGoing[i] = new AdvancedButton("Delete event");

                aBtnVotedTimeSlots[i].setId(eventId);
                aBtnViewEventDetails[i].setId(eventId);
                aBtnCancelGoing[i].setId(eventId);
                aLblText[i].setId(eventId);
                aContainer[i].setId(eventId);
                aComponentHolder[i].setId(eventId);
                System.err.println("@MyEvents Line 80 " + i);
                aBtnVotedTimeSlots[i].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {

                        final JFrame frame = new JFrame("Total votes");
                        frame.setLayout(new BorderLayout());
//                        JScrollPane scrollPane = new JScrollPane();
                        JPanel pnlTimeSlots = new JPanel(new GridLayout(14, 0, 10, 5));
//                        scrollPane.add(pnlTimeSlots);
                        frame.add(pnlTimeSlots, BorderLayout.CENTER);
                        JButton btnSave = new JButton("Save");
                        frame.add(btnSave, BorderLayout.SOUTH);
                        final ArrayList<HashMap<String, Object>> listEvtVotes = DaoEventVotes.listEventVotes(eventId);

                        final ArrayList<String> slotKey = new ArrayList<>();
                        final HashMap<String, Integer> slotVotes = new HashMap<>();

                        for (int p = 0; p < listEvtVotes.size(); p++) {
                            String timeSlot = listEvtVotes.get(p).get("startTimeId") + "-" + listEvtVotes.get(p).get("endTimeId");
                            if (slotVotes.isEmpty()) {
                                slotKey.add(timeSlot);
                                slotVotes.put(timeSlot,
                                        Integer.parseInt(listEvtVotes.get(p).get("countVotes").toString()));
                            } else if (slotVotes.containsKey(timeSlot)) {
                                slotVotes.put(timeSlot, (Integer.parseInt(listEvtVotes.get(p).get("countVotes").toString()) + 1));
                            } else if (!slotVotes.containsKey(timeSlot)) {
                                slotKey.add(timeSlot);
                                slotVotes.put(timeSlot, 1);
                            }
                        }

                        for (String s : slotKey) {
                            System.out.println(s);
                        }
                        final AdvancedRadioButton[] rdoVote = new AdvancedRadioButton[slotKey.size()];
                        final AdvancedLabel[] aLblTotalVotes = new AdvancedLabel[slotKey.size()];

                        for (int p = 0; p < evts.size(); p++) {
                            System.out.println(p);
                            if (((AdvancedButton) ae.getSource()).equals(aBtnVotedTimeSlots[p])) {
                                for (int j = 0; j < slotVotes.size(); j++) {
                                    rdoVote[j] = new AdvancedRadioButton(listEvtVotes.get(j).get("startTimeId") + ":00-" + listEvtVotes.get(j).get("endTimeId") + ":00");
                                    aLblTotalVotes[j] = new AdvancedLabel(slotVotes.get(slotKey.get(j)).toString() + " Votes");
                                    rdoVote[j].setId(eventId);
                                    JPanel pnlVoteCounts = new JPanel(new GridLayout(1, 2));
                                    pnlVoteCounts.add(rdoVote[j]);
                                    pnlVoteCounts.add(aLblTotalVotes[j]);
                                    pnlTimeSlots.add(pnlVoteCounts);
                                    rdoVote[j].addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent ae) {
                                            AdvancedRadioButton radioButton = (AdvancedRadioButton) ae.getSource();
                                            for (int p = 0; p < rdoVote.length; p++) {
                                                if (rdoVote[p].isSelected()) {
                                                    rdoVote[p].setSelected(false);
                                                }
                                            }
                                            radioButton.setSelected(true);
                                        }
                                    });
                                }
                            }
                        }

                        btnSave.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                for (int p = 0; p < slotKey.size(); p++) {
                                    if (rdoVote[p].isSelected()) {
                                        DaoEvent.updateEventVote(slotKey.get(p), eventId);
                                        JOptionPane.showMessageDialog(frame, "Event time updated.");
                                        frame.dispose();
                                    }
                                }
                            }
                        });
                        frame.setVisible(true);
                        frame.setSize(450, 350);
                        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    }
                });
//            aBtnCancelGoing[i].addActionListener(
//                    new ActionListener() {
//                @Override
//                public void actionPerformed(ActionEvent ae
//                ) {
//                    System.out.println(i);
//                    for (int p = 0; p < evts.size(); p++) {
//                        System.out.println(p);
//                        if ((ae.getSource()) == aBtnCancelGoing[p]) {
//                            evts.get(p).setAccepted(2);
////                            DaoEventInvitations.update(es.get(p));
//                            pnlAcceptedEvents.remove(aContainer[p]);
//                            pnlAcceptedEvents.revalidate();
//                            pnlAcceptedEvents.repaint();
//                        }
//                    }
//                }
//            }
//            );

                aBtnViewEventDetails[i].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        AdvancedButton button = (AdvancedButton) ae.getSource();
                        int id = button.getId();
                        HashMap<String, String> hm = DaoEvent.getEventByEventId(eventId);
                        WindowEventDetails windowEventDetails = new WindowEventDetails(
                                hm.get("event_name"),
                                hm.get("day_name"),
                                hm.get("host_name"),
                                ((hm.get("start_hour") + " - " + hm.get("end_hour")).equals("00:00 - 00:00") ? "Not confirmed yet" : hm.get("start_hour") + " - " + hm.get("end_hour")),
                                hm.get("event_location")
                        );
                        windowEventDetails.setTitle("Event details");
                        windowEventDetails.setVisible(true);
                        windowEventDetails.setDefaultCloseOperation(2);
                    }
                });
                aComponentHolder[i].setLayout(
                        new GridLayout(1, 3));
                aComponentHolder[i].add(aBtnVotedTimeSlots[i], 0);
                aComponentHolder[i].add(aBtnViewEventDetails[i], 1);
//            aComponentHolder[i].add(aBtnCancelGoing[i], 2);

                aContainer[i].setLayout(
                        new GridLayout(2, 1));
                aContainer[i].add(aLblText[i], 0);
                aContainer[i].add(aComponentHolder[i], 1);
                aComponentHolder[i].setBackground(Color.decode("#AA99DD"));
                aContainer[i].setBackground(Color.decode("#AA99DD"));
                aComponentHolder[i].revalidate();
                aComponentHolder[i].repaint();
                aContainer[i].revalidate();
                aContainer[i].repaint();

                pnlAcceptedEvents.add(aContainer[i], 0);
                pnlAcceptedEvents.revalidate();

                pnlAcceptedEvents.repaint();
            }
        }

        return pnlAcceptedEvents;
    }
}
