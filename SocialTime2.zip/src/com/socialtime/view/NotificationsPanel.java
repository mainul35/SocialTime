/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.socialtime.view;

import com.socialtime.dao.DaoEventInvitations;
import com.socialtime.dao.DaoEventVotes;
import com.socialtime.model.Eventinvitations;
import com.socialtime.model.Eventvotes;
import com.socialtime.model.Useravailability;
import com.socialtime.util.windowComponent.AdvancedButton;
import com.socialtime.util.windowComponent.AdvancedLabel;
import com.socialtime.util.windowComponent.AdvancedPanel;
import static com.socialtime.view.Home.home;
import static com.socialtime.view.Home.tabbedPane;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Mainul35
 */
public class NotificationsPanel {

    static int i = 0;
    private Eventinvitations eventinvitations;

    public JPanel getNotificationsPanel() {
        AdvancedPanel[] aContainer = new AdvancedPanel[100];
        //JPanel();
        AdvancedPanel[] aComponentHolder = new AdvancedPanel[100];
//    JCheckBox("Edit Permission");
        AdvancedButton[] aBtnSubmit = new AdvancedButton[100];
        //JButton("Submit");
        AdvancedButton[] aBtnClose = new AdvancedButton[100];
        //JButton("Close");
        AdvancedLabel[] aLblText = new AdvancedLabel[100];

        JPanel pnlNotifications = new JPanel();

        pnlNotifications.setLayout(
                new GridLayout(5, 0, 10, 8)
        );
        System.err.println(
                "@Line 101 in ShowInvitations class ....");
        Stream<Eventinvitations> es = DaoEventInvitations.listEventInvitations(0).stream().filter(e -> e.getUsers().getEmail().equals(Home.user.getEmail()));

        final Random rn = new Random();

        es.forEach(
                new Consumer<Eventinvitations>() {
            @Override
            public void accept(Eventinvitations cnsmr
            ) {
                eventinvitations = cnsmr;
                if (!cnsmr.getEvent().getUsers().getEmail().equals(Home.user.getEmail())) {
                    int invitationId = cnsmr.getInvitationId();
                    aLblText[i] = new AdvancedLabel("<html>" + cnsmr.getEvent().getUsers().getName() + " Invited you for " + cnsmr.getEvent().getEventName()
                            + " event.<br>"
                            + "Day: " + cnsmr.getEvent().getDay().getDayName() + "<br>"
                            + "</html>");
                    aComponentHolder[i] = new AdvancedPanel();
                    aContainer[i] = new AdvancedPanel();
                    aBtnSubmit[i] = new AdvancedButton("Accept");
                    aBtnClose[i] = new AdvancedButton("Deny");

                    aBtnClose[i].setId(invitationId);
                    aBtnSubmit[i].setId(invitationId);
                    aLblText[i].setId(invitationId);
                    aContainer[i].setId(invitationId);
                    aComponentHolder[i].setId(invitationId);

                    aComponentHolder[i].setLayout(new GridLayout(1, 2));
                    aComponentHolder[i].add(aBtnSubmit[i], 0);
                    aComponentHolder[i].add(aBtnClose[i], 1);

                    aContainer[i].setLayout(new GridLayout(2, 1));
                    aContainer[i].add(aLblText[i], 0);
                    aContainer[i].add(aComponentHolder[i], 1);
                    aComponentHolder[i].setBackground(Color.decode("#AA99DD"));
                    aContainer[i].setBackground(Color.decode("#AA99DD"));
                    aComponentHolder[i].revalidate();
                    aComponentHolder[i].repaint();
                    aContainer[i].revalidate();
                    aContainer[i].repaint();

                    pnlNotifications.add(aContainer[i], 0);
                    pnlNotifications.repaint();
//                    System.out.println("@Line 138 in ShowInvitations class ....");

                    aBtnSubmit[i].addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            if (eventinvitations.getUsers().getUseravailabilities().size() > 0) {
                                eventinvitations.setAccepted(1);
                                DaoEventInvitations.update(eventinvitations);
                                Set<Useravailability> set = eventinvitations.getUsers().getUseravailabilities();
                                for (Iterator<Useravailability> iterator = set.iterator(); iterator.hasNext();) {
                                    
                                    Useravailability useravailability = iterator.next();
                                    final Eventvotes eventvotes = new Eventvotes();
                                    eventvotes.setEventinvitations(eventinvitations);
                                    eventvotes.setCountVotes(eventvotes.getCountVotes());
                                    eventvotes.setEventId(eventinvitations.getEvent().getEventId());
                                    eventvotes.setHoursByEndTimeId(useravailability.getHoursByEndTimeId());
                                    eventvotes.setHoursByStartTimeId(useravailability.getHoursByStartTimeId());
                                    int randId = rn.nextInt((int) System.currentTimeMillis()) + 10;
                                    eventvotes.setPoolId(randId);
                                    DaoEventVotes.addEventvote(eventvotes);
                                    System.err.println(useravailability.getHoursByStartTimeId().getHour()+" - "+useravailability.getHoursByEndTimeId().getHour());
                                }
                                pnlNotifications.remove(aContainer[i]);
                                pnlNotifications.revalidate();
                                pnlNotifications.repaint();
                            } else {
                                JOptionPane.showMessageDialog(home, "Please set your available time slots from profile edit panel first.");
                            }
                        }
                    });

                    aBtnClose[i].addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent ae) {
                            eventinvitations.setAccepted(2);
                            DaoEventInvitations.update(eventinvitations);
                            pnlNotifications.remove(aContainer[i]);
                            pnlNotifications.revalidate();
                            pnlNotifications.repaint();
                        }
                    });
                }
            }
        }
        );
        return pnlNotifications;
    }
}
